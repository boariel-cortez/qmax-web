// main.js — QMAX Bolivia
// Funciones: navbar scroll, menú mobile, validación formulario y animaciones

document.addEventListener('DOMContentLoaded', () => {
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 60) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  const burgerBtn = document.getElementById('burgerBtn');
  const navLinks = document.getElementById('navLinks');

  if (burgerBtn && navLinks && navbar) {
    const cerrarMenu = () => {
      navLinks.classList.remove('open');
      navbar.classList.remove('menu-open');
      document.body.classList.remove('menu-open');
    };

    burgerBtn.addEventListener('click', () => {
      const isOpen = navLinks.classList.toggle('open');
      navbar.classList.toggle('menu-open', isOpen);
      document.body.classList.toggle('menu-open', isOpen);
    });

    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', cerrarMenu);
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 720) {
        cerrarMenu();
      }
    });
  }

  document.querySelectorAll('.faq__item').forEach((item) => {
    item.addEventListener('toggle', () => {
      const icon = item.querySelector('.faq__icon');
      if (icon) {
        icon.textContent = item.open ? '−' : '+';
      }
    });
  });

  function mostrarError(input, mensaje) {
    input.classList.add('error');
    const errDiv = document.createElement('div');
    errDiv.className = 'field-error';
    errDiv.textContent = mensaje;
    errDiv.style.cssText = 'color:#ff6b6b;font-size:0.78rem;margin-top:4px;';
    input.parentNode.appendChild(errDiv);
  }

  function validarFormulario(form) {
    let valido = true;

    form.querySelectorAll('.field-error').forEach((el) => el.remove());
    form.querySelectorAll('.error').forEach((el) => el.classList.remove('error'));

    const nombre = form.querySelector('[name="nombre"]');
    if (nombre && nombre.value.trim().length < 2) {
      mostrarError(nombre, 'Por favor ingresa tu nombre completo.');
      valido = false;
    }

    const telefono = form.querySelector('[name="telefono"]');
    if (telefono) {
      const digits = telefono.value.replace(/[\s\-\+\(\)]/g, '');
      if (!digits || Number.isNaN(Number(digits)) || digits.length < 7) {
        mostrarError(telefono, 'Ingresa un número de teléfono válido.');
        valido = false;
      }
    }

    ['ciudad', 'modelo_interes', 'uso_principal'].forEach((fieldName) => {
      const field = form.querySelector(`[name="${fieldName}"]`);
      if (field && !field.value.trim()) {
        mostrarError(field, 'Este campo es obligatorio.');
        valido = false;
      }
    });

    return valido;
  }

  const formRegistro = document.getElementById('formRegistro');
  if (formRegistro) {
    formRegistro.addEventListener('submit', (e) => {
      if (!validarFormulario(formRegistro)) {
        e.preventDefault();
        const primerError = formRegistro.querySelector('.error');
        if (primerError) {
          primerError.focus();
          primerError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        return;
      }

      const btn = formRegistro.querySelector('[type="submit"]');
      if (btn) {
        btn.disabled = true;
        btn.textContent = 'Enviando...';
      }
    });
  }

  const animados = document.querySelectorAll(
    '.beneficio-card, .moto-card, .testimonio-card, .por-que__item, .faq__item'
  );

  if ('IntersectionObserver' in window && animados.length) {
    animados.forEach((el, i) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(28px)';
      el.style.transition = `opacity 0.5s ease ${(i % 3) * 0.1}s, transform 0.5s ease ${(i % 3) * 0.1}s`;
    });

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    animados.forEach((el) => observer.observe(el));
  }

  document.querySelectorAll('.moto-card__cta').forEach((btn) => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.moto-card');
      const nombre = card?.querySelector('.moto-card__name')?.textContent?.trim();
      const select = document.getElementById('modelo_interes_registro');

      if (nombre && select) {
        Array.from(select.options).forEach((opt) => {
          if (opt.text === nombre) {
            opt.selected = true;
          }
        });
      }
    });
  });

  console.log('[QMAX] Web cargada correctamente.');
});
