# static/img — Instrucciones de imágenes

Coloca aquí los siguientes archivos de imagen:

| Archivo               | Descripción                        | Resolución recomendada |
|-----------------------|------------------------------------|------------------------|
| placeholder-hero.jpg  | Imagen hero de fondo (moto o ciudad) | 1920x1080 px mínimo    |
| moto-urbana.jpg       | Foto del modelo QMAX Urban         | 800x500 px             |
| moto-delivery.jpg     | Foto del modelo QMAX Cargo         | 800x500 px             |
| moto-sport.jpg        | Foto del modelo QMAX Sport         | 800x500 px             |
| logo.png              | Logo de QMAX (transparente)        | 200x80 px              |
| favicon.png           | Ícono del sitio                    | 32x32 px               |

## Tips:
- Comprime las imágenes antes de subirlas. Usa https://squoosh.app o https://tinypng.com
- Formato .jpg para fotos, .png para logos y elementos con transparencia
- El hero debe ser oscuro o tener contraste suficiente para que el texto sea legible
- Mientras no tengas fotos propias, puedes usar imágenes de motos eléctricas de:
  - https://unsplash.com (busca "electric motorcycle" o "electric scooter")
  - https://pexels.com
  - Fotos de los catálogos de los fabricantes chinos (para uso interno/referencial)
