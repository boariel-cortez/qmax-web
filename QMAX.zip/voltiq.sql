-- ============================================================
-- QMAX / VOLTIQ - Base de datos MySQL
-- Archivo corregido para instalación limpia en Laragon / HeidiSQL
-- Nota: se mantiene el nombre interno voltiq_db por compatibilidad.
-- ============================================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS voltiq_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE voltiq_db;

-- ============================================================
-- Tabla: leads
-- Guarda todos los interesados capturados desde la landing
-- ============================================================
CREATE TABLE IF NOT EXISTS leads (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre          VARCHAR(100)  NOT NULL,
  telefono        VARCHAR(20)   NOT NULL,
  email           VARCHAR(150)  NULL,
  ciudad          VARCHAR(80)   NULL,
  presupuesto     VARCHAR(50)   NULL,
  uso_principal   VARCHAR(80)   NULL,
  modelo_interes  VARCHAR(100)  NULL,
  mensaje         TEXT          NULL,
  tipo_formulario VARCHAR(30)   NOT NULL DEFAULT 'registro_unico',
  fuente          VARCHAR(80)   NULL,
  fecha_registro  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  leido           TINYINT(1)    NOT NULL DEFAULT 0,
  notas_internas  TEXT          NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Índices para búsquedas rápidas
-- ============================================================
CREATE INDEX idx_fecha ON leads (fecha_registro);
CREATE INDEX idx_tipo  ON leads (tipo_formulario);
CREATE INDEX idx_leido ON leads (leido);

-- ============================================================
-- Datos de prueba (opcional)
-- Borra este bloque si no quieres insertar ejemplos.
-- ============================================================
INSERT INTO leads (nombre, telefono, email, ciudad, presupuesto, uso_principal, modelo_interes, mensaje, tipo_formulario, fuente)
VALUES
  ('Carlos Perez', '72345678', NULL, 'La Paz', NULL, 'Transporte diario', 'QMAX Urban', NULL, 'registro_unico', 'web-registro'),
  ('María Antezana', '68901234', NULL, 'Cochabamba', NULL, 'Trabajo / delivery', 'QMAX Cargo', NULL, 'registro_unico', 'web-registro');

-- ============================================================
-- Vista útil para ver leads nuevos
-- ============================================================
CREATE OR REPLACE VIEW v_leads_nuevos AS
SELECT id, nombre, telefono, ciudad, modelo_interes, tipo_formulario, fecha_registro
FROM leads
WHERE leido = 0
ORDER BY fecha_registro DESC;

-- ============================================================
-- Migración opcional para una base ya existente
-- Ejecuta solo si quieres actualizar datos viejos a la nueva marca.
-- ============================================================
-- UPDATE leads SET modelo_interes = 'QMAX Urban' WHERE modelo_interes = 'Voltiq Urban';
-- UPDATE leads SET modelo_interes = 'QMAX Cargo' WHERE modelo_interes = 'Voltiq Cargo';
-- UPDATE leads SET modelo_interes = 'QMAX Sport' WHERE modelo_interes = 'Voltiq Sport';
-- UPDATE leads SET tipo_formulario = 'registro_unico' WHERE tipo_formulario IN ('contacto', 'reserva');
-- UPDATE leads SET fuente = 'web-registro' WHERE fuente IS NULL OR fuente = '';
