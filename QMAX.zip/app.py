from datetime import datetime
import os
import re
import time

from flask import Flask, flash, jsonify, redirect, render_template, request, url_for
from flask_sqlalchemy import SQLAlchemy

from config import config


app = Flask(__name__)

env = os.environ.get('FLASK_ENV', 'development')
app.config.from_object(config[env])

db = SQLAlchemy(app)


class Lead(db.Model):
    """Modelo que representa un lead/interesado capturado por la web."""

    __tablename__ = 'leads'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(100), nullable=False)
    telefono = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(150), nullable=True)
    ciudad = db.Column(db.String(80), nullable=True)
    presupuesto = db.Column(db.String(50), nullable=True)
    uso_principal = db.Column(db.String(80), nullable=True)
    modelo_interes = db.Column(db.String(100), nullable=True)
    mensaje = db.Column(db.Text, nullable=True)
    tipo_formulario = db.Column(db.String(30), nullable=False, default='contacto')
    fuente = db.Column(db.String(80), nullable=True)
    fecha_registro = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    leido = db.Column(db.Boolean, nullable=False, default=False)

    def __repr__(self):
        return f'<Lead {self.nombre} - {self.telefono}>'


def sanitizar_texto(texto: str, max_len: int = 200) -> str:
    """Limpia y limita un campo de texto para evitar inyecciones."""
    if not texto:
        return ''
    texto = texto.strip()
    texto = re.sub(r'[<>"\']', '', texto)
    return texto[:max_len]


def validar_telefono(tel: str) -> bool:
    """Valida que el teléfono tenga entre 7 y 15 dígitos."""
    digitos = re.sub(r'[\s\-\+\(\)]', '', tel)
    return digitos.isdigit() and 7 <= len(digitos) <= 15


MODELOS_CATALOGO = [
    {
        'id': 'urban',
        'nombre': 'QMAX Urban',
        'slug': 'Qmax-urban',
        'descripcion': 'La moto ideal para moverte en ciudad. Ligera, ágil y eficiente. Perfecta para el tráfico diario de Santa Cruz, Cochabamba o La Paz.',
        'autonomia': '80 km',
        'velocidad': '60 km/h',
        'carga': '4-6 horas',
        'precio_ref': 'Desde 7.000 Bs',
        'imagen': 'moto-urbana.jpg',
        'badge': 'Más popular',
        'ideal_para': ['Ciudad', 'Uso diario', 'Jóvenes'],
    },
    {
        'id': 'cargo',
        'nombre': 'QMAX Cargo',
        'slug': 'Qmax-cargo',
        'descripcion': 'Diseñada para trabajo y delivery. Carga mayor, batería de larga duración, construcción robusta. Tu aliada para generar ingresos.',
        'autonomia': '120 km',
        'velocidad': '55 km/h',
        'carga': '5-7 horas',
        'precio_ref': 'Desde 10.000 Bs',
        'imagen': 'moto-delivery.jpg',
        'badge': 'Para delivery',
        'ideal_para': ['Delivery', 'Trabajo', 'Negocio'],
    },
    {
        'id': 'sport',
        'nombre': 'QMAX Sport',
        'slug': 'Qmax-sport',
        'descripcion': 'Para quien quiere estilo y potencia. Diseño moderno, mayor velocidad y una experiencia de manejo superior en rutas y ciudad.',
        'autonomia': '100 km',
        'velocidad': '90 km/h',
        'carga': '4-5 horas',
        'precio_ref': 'Desde 15.000 Bs',
        'imagen': 'moto-sport.jpg',
        'badge': 'Alta gama',
        'ideal_para': ['Ruta', 'Estilo', 'Performance'],
    },
]

PREGUNTAS_FRECUENTES = [
    {
        'pregunta': '¿Necesito sacar patente para una moto eléctrica en Bolivia?',
        'respuesta': 'No lo necesitas para una moto eléctrica de uso personal en Bolivia. Te asesoramos en cada paso para que realices tu trámite de forma fácil, rápida y segura.',
    },
    {
        'pregunta': '¿Dónde se carga la moto eléctrica?',
        'respuesta': 'En cualquier enchufe doméstico estándar (220V en Bolivia). No necesitas instalación especial. Conectas la moto como cargas tu celular, mientras duermes.',
    },
    {
        'pregunta': '¿Cuánto cuesta cargar la batería completamente?',
        'respuesta': 'Aproximadamente 2 a 5 bolivianos por carga completa, dependiendo del modelo. Comparado con 30-60 Bs en gasolina, el ahorro es enorme.',
    },
    {
        'pregunta': '¿Qué pasa si la batería falla o se agota?',
        'respuesta': 'Las baterías tienen garantía y vida útil de varios años. Además, te proveemos soporte técnico y acceso a repuestos desde el primer día.',
    },
    {
        'pregunta': '¿Puedo usar la moto en subidas muy empinadas?',
        'respuesta': 'Nuestros modelos están seleccionados para adaptarse a distintas geografías bolivianas. Conversemos sobre tu zona específica y te recomendamos el modelo ideal.',
    },
    {
        'pregunta': '¿Cuándo estarán disponibles para comprar?',
        'respuesta': 'Disponibles muy pronto. No esperes: reserva ahora o contáctanos y sé de los primeros en tener la tuya.',
    },
]


@app.context_processor
def inject_global_data():
    fuente_actual = sanitizar_texto(request.args.get('fuente', ''), 80).lower()
    fuentes_validas = ['facebook', 'instagram', 'tiktok', 'organico']

    if fuente_actual not in fuentes_validas:
        fuente_actual = ''

    return {
        'whatsapp_number': app.config['WHATSAPP_NUMBER'],
        'whatsapp_msg': app.config['WHATSAPP_MSG'],
        'contact_email': app.config['CONTACT_EMAIL'],
        'contact_phone': app.config['CONTACT_PHONE'],
        'contact_city': app.config.get('CONTACT_CITY', 'Bolivia'),
        'social_facebook': app.config['SOCIAL_FACEBOOK'],
        'social_instagram': app.config['SOCIAL_INSTAGRAM'],
        'social_tiktok': app.config['SOCIAL_TIKTOK'],
        'current_year': datetime.now().year,
        'fuente_actual': fuente_actual,
    }

@app.route('/')
def index():
    fuente = sanitizar_texto(request.args.get('fuente', ''), 80).lower()

    fuentes_validas = ['facebook', 'instagram', 'tiktok', 'organico']

    if fuente not in fuentes_validas:
        fuente = 'directo'

    return render_template(
        'index.html',
        modelos=MODELOS_CATALOGO,
        faqs=PREGUNTAS_FRECUENTES,
        fuente_detectada=fuente,
        form_ts=int(time.time()),
    )


@app.route('/gracias')
def gracias():
    return render_template('gracias.html')


@app.route('/registro', methods=['POST'])
def registro():
    nombre = sanitizar_texto(request.form.get('nombre', ''), 100)
    ciudad = sanitizar_texto(request.form.get('ciudad', ''), 80)
    telefono = sanitizar_texto(request.form.get('telefono', ''), 12)
    modelo_interes = sanitizar_texto(request.form.get('modelo_interes', ''), 100)
    uso_principal = sanitizar_texto(request.form.get('uso_principal', ''), 80)
    fuente = sanitizar_texto(request.form.get('fuente', 'directo'), 80).lower()

    # Anti-spam: honeypot
    website = sanitizar_texto(request.form.get('website', ''), 150)

    # Anti-spam: tiempo mínimo de llenado
    form_ts = request.form.get('form_ts', '0')

    if website:
        print('[SPAM] Honeypot activado.')
        return redirect(url_for('gracias'))

    try:
        form_ts = int(form_ts)
    except ValueError:
        form_ts = 0

    if form_ts and (time.time() - form_ts) < 3:
        print('[SPAM] Formulario enviado demasiado rápido.')
        return redirect(url_for('gracias'))

    errores = []
    if not nombre or len(nombre) < 2:
        errores.append('El nombre es obligatorio.')
    if not ciudad:
        errores.append('La ciudad es obligatoria.')
    if not telefono or not validar_telefono(telefono):
        errores.append('El teléfono debe tener entre 7 y 15 dígitos.')
    if not modelo_interes:
        errores.append('Debes seleccionar un modelo de interés.')
    if not uso_principal:
        errores.append('Debes indicar para qué usarías la moto.')

    if errores:
        flash(' | '.join(errores), 'error')
        if fuente in ['facebook', 'instagram', 'tiktok', 'organico']:
            return redirect(url_for('index', fuente=fuente) + '#registro')
        return redirect(url_for('index') + '#registro')

    try:
        nuevo_lead = Lead(
            nombre=nombre,
            telefono=telefono,
            email=None,
            ciudad=ciudad,
            presupuesto=None,
            uso_principal=uso_principal,
            modelo_interes=modelo_interes,
            mensaje=None,
            tipo_formulario='registro_unico',
            fuente=fuente,
        )
        db.session.add(nuevo_lead)
        db.session.commit()
    except Exception as e:
        print(f'[ERROR BD] {e}')
        flash('Hubo un problema al guardar tu registro. Por favor intenta de nuevo.', 'error')
        if fuente in ['facebook', 'instagram', 'tiktok', 'organico']:
            return redirect(url_for('index', fuente=fuente) + '#registro')
        return redirect(url_for('index') + '#registro')

    return redirect(url_for('gracias'))


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print('[QMAX] Tablas verificadas en MySQL.')

    print('[QMAX] Servidor iniciado en http://localhost:5000')
    app.run(host='0.0.0.0', port=5000, debug=False)
