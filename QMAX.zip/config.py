# config.py
# ============================================================
# Configuración central de la aplicación QMAX
# Separa la config del código principal (buena práctica)
# ============================================================

import os
from dotenv import load_dotenv

# Carga variables del archivo .env (no subir .env a git)
load_dotenv()

class Config:
    # ── Seguridad ────────────────────────────────────────────
    SECRET_KEY = os.environ.get('SECRET_KEY', 'voltiq-dev-secret-cambia-esto-en-produccion')

    # ── Base de Datos MySQL (Laragon) ────────────────────────
    # Formato: mysql+pymysql://usuario:password@host:puerto/nombre_bd
    DB_USER     = os.environ.get('DB_USER',     'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')       # Laragon: sin password por defecto
    DB_HOST     = os.environ.get('DB_HOST',     'localhost')
    DB_PORT     = os.environ.get('DB_PORT',     '3306')
    DB_NAME     = os.environ.get('DB_NAME',     'voltiq_db')

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False  # Evita overhead innecesario

    # ── WhatsApp ─────────────────────────────────────────────
    # Cambia por tu número real con código de país (591 = Bolivia)
    WHATSAPP_NUMBER = os.environ.get('WHATSAPP_NUMBER', '59173352295')
    WHATSAPP_MSG    = 'Hola, me interesa saber más sobre las motos eléctricas QMAX.'

    # ── Datos de contacto visibles en la web ─────────────────
    CONTACT_EMAIL   = 'qmaxbolivia@gmail.com'
    CONTACT_PHONE   = '+591 7 335-2295'
    CONTACT_CITY    = 'Santa Cruz, Bolivia'

    # ── Redes sociales ───────────────────────────────────────
    SOCIAL_FACEBOOK  = 'https://www.facebook.com/QMAXBolivia/'
    SOCIAL_INSTAGRAM = 'https://www.instagram.com/qmax.bol'
    SOCIAL_TIKTOK    = 'https://www.tiktok.com/@qmax.bol' # ── En un futuro quiero cambiar a QMAX.bo o QMAXbolivia


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    # En producción usa variables de entorno reales, nunca hardcoding


# Selector de entorno
config = {
    'development': DevelopmentConfig,
    'production':  ProductionConfig,
    'default':     DevelopmentConfig,
}
